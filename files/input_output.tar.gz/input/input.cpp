#include<iostream>

using namespace std;

int main() {

    int N;
    
    cout << "Enter a number: ";
    cin >> N;
    cout << "You entered the number " << N << endl;

    return 0;

}
